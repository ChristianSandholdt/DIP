// metoder.js
let a = [0,1,2,3];
console.log(a.length); // => 4
a.push(4);
console.log(a); // => [ 0, 1, 2, 3, 4 ]
console.log(a.includes(2));
console.log(a.shift()); // => 0
console.log(a); // => [ 1, 2, 3, 4 ]