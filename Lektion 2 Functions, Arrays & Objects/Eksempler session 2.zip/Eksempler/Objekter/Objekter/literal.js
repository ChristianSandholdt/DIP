// literal.js
let o = {id: 123, '3 tal': [7, 9, 13]};
