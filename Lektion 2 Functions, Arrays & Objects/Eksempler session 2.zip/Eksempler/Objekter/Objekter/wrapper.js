// wrapper.js
let i = 123;
console.log(i.toExponential()); // => 1.23e+2
let s = "test";
console.log(s.p); // => undefined
console.log(s.length); // => 4
console.log(s[2]); // => s
console.log(s.toUpperCase()); // => TEST
let b = true;
console.log(b.toString()); // => true
